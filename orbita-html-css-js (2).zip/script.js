/* ORBÍTA — interacciones del prototipo. Datos guardados en el navegador (localStorage). */
"use strict";

const products = [
  {id:1,name:"Audífonos inalámbricos",category:"Tecnología",price:129,oldPrice:179,emoji:"🎧",seller:"NovaTech",tag:"Oferta"},
  {id:2,name:"Smartwatch deportivo",category:"Tecnología",price:199,oldPrice:259,emoji:"⌚",seller:"Click Store",tag:"Popular"},
  {id:3,name:"Lámpara minimalista",category:"Hogar",price:89,emoji:"💡",seller:"Casa Viva"},
  {id:4,name:"Mochila urbana",category:"Moda",price:119,oldPrice:149,emoji:"🎒",seller:"Distrito 21",tag:"Oferta"},
  {id:5,name:"Set de entrenamiento",category:"Deportes",price:149,emoji:"🏋️",seller:"Fit Market"},
  {id:6,name:"Cuidado facial",category:"Belleza",price:79,emoji:"🧴",seller:"Aura Beauty"},
  {id:7,name:"Set de bloques",category:"Juguetes",price:69,emoji:"🧸",seller:"Peque Mundo"},
  {id:8,name:"Accesorios para mascotas",category:"Mascotas",price:59,emoji:"🐾",seller:"Pet House"},
  {id:9,name:"Teclado mecánico",category:"Tecnología",price:229,oldPrice:279,emoji:"⌨️",seller:"NovaTech",tag:"Nuevo"},
  {id:10,name:"Silla decorativa",category:"Hogar",price:289,emoji:"🪑",seller:"Casa Viva"},
  {id:11,name:"Zapatillas urbanas",category:"Deportes",price:179,emoji:"👟",seller:"Fit Market"},
  {id:12,name:"Bolso de diseño",category:"Moda",price:159,emoji:"👜",seller:"Distrito 21"}
];

const $ = (selector) => document.querySelector(selector);
const money = (value) => `S/ ${value.toFixed(2)}`;
let selectedCategory = "Todas";
let showFavorites = false;
let cart = load("orbita_cart", []);
let favorites = load("orbita_favorites", []);

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}
function saveState() {
  localStorage.setItem("orbita_cart", JSON.stringify(cart));
  localStorage.setItem("orbita_favorites", JSON.stringify(favorites));
}
function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove("show"), 2300);
}
function getVisibleProducts() {
  const query = $("#searchInput").value.trim().toLowerCase();
  let list = products.filter(p => {
    const categoryMatch = selectedCategory === "Todas" || p.category === selectedCategory;
    const queryMatch = `${p.name} ${p.category} ${p.seller}`.toLowerCase().includes(query);
    const favoriteMatch = !showFavorites || favorites.includes(p.id);
    return categoryMatch && queryMatch && favoriteMatch;
  });
  const sort = $("#sortSelect").value;
  if (sort === "low") list.sort((a,b) => a.price-b.price);
  if (sort === "high") list.sort((a,b) => b.price-a.price);
  if (sort === "name") list.sort((a,b) => a.name.localeCompare(b.name,"es"));
  return list;
}
function renderProducts() {
  const list = getVisibleProducts();
  $("#productsTitle").textContent = showFavorites ? "Mis favoritos" : selectedCategory === "Todas" ? "Descubre productos" : selectedCategory;
  $("#productGrid").innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-image">
        ${p.tag ? `<span class="product-tag">${p.tag}</span>` : ""}
        <span class="product-emoji">${p.emoji}</span>
        <button class="favorite-button ${favorites.includes(p.id) ? "is-favorite" : ""}" data-favorite="${p.id}" aria-label="Agregar ${p.name} a favoritos">${favorites.includes(p.id) ? "♥" : "♡"}</button>
      </div>
      <div class="product-info">
        <span class="product-meta">${p.category} · ${p.seller}</span>
        <h3>${p.name}</h3>
        <div class="product-price">${money(p.price)} ${p.oldPrice ? `<del>${money(p.oldPrice)}</del>` : ""}</div>
        <span class="product-seller">Vendido por ${p.seller}</span>
        <button class="add-button" data-add="${p.id}">Agregar al carrito</button>
      </div>
    </article>`).join("");
  $("#emptyState").classList.toggle("hidden", list.length !== 0);
}
function addToCart(id) {
  const existing = cart.find(item => item.id === id);
  if (existing) existing.quantity += 1;
  else cart.push({id,quantity:1});
  saveState(); renderCart(); toast("Producto agregado al carrito");
}
function changeQuantity(id, delta) {
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) cart = cart.filter(x => x.id !== id);
  saveState(); renderCart();
}
function renderCart() {
  const count = cart.reduce((sum,item) => sum + item.quantity, 0);
  const total = cart.reduce((sum,item) => {
    const product = products.find(p => p.id === item.id);
    return sum + (product ? product.price * item.quantity : 0);
  }, 0);
  $("#cartCount").textContent = count;
  $("#drawerCount").textContent = `(${count})`;
  $("#cartSubtotal").textContent = money(total);
  $("#cartItems").innerHTML = cart.length ? cart.map(item => {
    const p = products.find(product => product.id === item.id);
    if (!p) return "";
    return `<div class="cart-line">
      <div class="cart-line-emoji">${p.emoji}</div>
      <div><h4>${p.name}</h4><small>${money(p.price)} · ${p.seller}</small>
        <div class="quantity-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Restar">−</button><b>${item.quantity}</b><button data-qty="${p.id}" data-delta="1" aria-label="Sumar">+</button></div>
        <button class="remove-line" data-remove="${p.id}">Eliminar</button>
      </div><strong>${money(p.price * item.quantity)}</strong>
    </div>`;
  }).join("") : `<div class="cart-empty">Tu carrito está vacío.<br><br>Explora nuestros productos y agrega tus favoritos.</div>`;
}
function openCart() {
  $("#cartDrawer").classList.add("open");
  $("#cartDrawer").setAttribute("aria-hidden","false");
  $("#overlay").classList.add("visible");
}
function closeCart() {
  $("#cartDrawer").classList.remove("open");
  $("#cartDrawer").setAttribute("aria-hidden","true");
  $("#overlay").classList.remove("visible");
}
function selectCategory(category) {
  selectedCategory = category;
  showFavorites = false;
  document.querySelectorAll(".category-card").forEach(btn => btn.classList.toggle("active", btn.dataset.category === category));
  renderProducts();
}

$("#productGrid").addEventListener("click", event => {
  const add = event.target.closest("[data-add]");
  const fav = event.target.closest("[data-favorite]");
  if (add) addToCart(Number(add.dataset.add));
  if (fav) {
    const id = Number(fav.dataset.favorite);
    favorites = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites,id];
    saveState(); renderProducts(); toast(favorites.includes(id) ? "Guardado en favoritos" : "Eliminado de favoritos");
  }
});
$("#cartItems").addEventListener("click", event => {
  const qty = event.target.closest("[data-qty]");
  const remove = event.target.closest("[data-remove]");
  if (qty) changeQuantity(Number(qty.dataset.qty), Number(qty.dataset.delta));
  if (remove) { cart = cart.filter(x => x.id !== Number(remove.dataset.remove)); saveState(); renderCart(); }
});
$("#categoryGrid").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (button) selectCategory(button.dataset.category);
});
$("#searchInput").addEventListener("input", renderProducts);
$("#sortSelect").addEventListener("change", renderProducts);
$("#showAllCategories").addEventListener("click", () => selectCategory("Todas"));
$("#favoritesToggle").addEventListener("click", () => {
  showFavorites = !showFavorites;
  selectedCategory = "Todas";
  document.querySelectorAll(".category-card").forEach(btn => btn.classList.toggle("active", btn.dataset.category === "Todas"));
  renderProducts();
  document.querySelector("#productos").scrollIntoView({behavior:"smooth"});
});
$("#cartOpen").addEventListener("click", openCart);
$("#cartClose").addEventListener("click", closeCart);
$("#overlay").addEventListener("click", closeCart);
$("#checkoutButton").addEventListener("click", () => {
  if (!cart.length) return toast("Agrega productos antes de continuar");
  alert("Este es un prototipo: todavía no procesa pagos ni registra pedidos reales.");
});
$("#accountButton").addEventListener("click", () => $("#accountModal").showModal());
$("#accountOk").addEventListener("click", () => $("#accountModal").close());
$("#sellerOpen").addEventListener("click", () => $("#sellerModal").showModal());
$("#sellerForm").addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent("Solicitud para vender en ORBÍTA");
  const body = encodeURIComponent(
    `Nombre/empresa: ${data.get("name")}\\nCorreo: ${data.get("email")}\\nTeléfono: ${data.get("phone")}\\nProductos: ${data.get("products")}`
  );
  toast("Preparando tu solicitud de vendedor");
  window.location.href = `mailto:contacto@orbita.pe?subject=${subject}&body=${body}`;
  $("#sellerModal").close();
});
$("#mobileMenu").addEventListener("click", () => {
  const nav = $("#mainNav");
  nav.classList.toggle("open");
  $("#mobileMenu").setAttribute("aria-expanded", nav.classList.contains("open") ? "true" : "false");
});
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("#mainNav").classList.remove("open")));
$("#year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
